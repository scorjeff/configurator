<?php
/*
Plugin Name: configurator
Plugin URI: https://espador.com/
Description: configurator shoes
Author: boisgontier pour espador
Version: 1.0
Author URI: http://espador.com/
*/
header('Localisation:  /home/jeff/eclipse-workspace/configurateur/configEspador/index.html');
exit();